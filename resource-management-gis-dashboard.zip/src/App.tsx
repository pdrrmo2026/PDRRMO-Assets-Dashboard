import { useState } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import EquipmentForm from './components/EquipmentForm';
import VehicleForm from './components/VehicleForm';
import PersonnelForm from './components/PersonnelForm';
import ResourceList from './components/ResourceList';
import GISMap from './components/GISMap';
import AgencyDownloads from './components/AgencyDownloads';
import ACDVForm from './components/ACDVForm';
import ACDVList from './components/ACDVList';
import Login from './components/Login';
import { Equipment, Vehicle, Personnel, ACDV, TabType } from './types';

// Sample data - initially empty, will be populated via forms
const initialEquipment: Equipment[] = [];

const initialVehicles: Vehicle[] = [];

const initialPersonnel: Personnel[] = [];

const initialACDV: ACDV[] = [];

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<string>('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const [equipment, setEquipment] = useState<Equipment[]>(initialEquipment);
  const [vehicles, setVehicles] = useState<Vehicle[]>(initialVehicles);
  const [personnel, setPersonnel] = useState<Personnel[]>(initialPersonnel);
  const [acdvData, setACDVData] = useState<ACDV[]>(initialACDV);

  const handleLogin = (username: string, admin: boolean) => {
    setCurrentUser(username);
    setIsAdmin(admin);
    setIsLoggedIn(true);
  };

  const addEquipment = (item: Omit<Equipment, 'id' | 'dateAdded'>) => {
    const newItem: Equipment = {
      ...item,
      id: Date.now().toString(),
      dateAdded: new Date().toISOString().split('T')[0],
    };
    setEquipment([...equipment, newItem]);
  };

  const addVehicle = (item: Omit<Vehicle, 'id' | 'dateAdded'>) => {
    const newItem: Vehicle = {
      ...item,
      id: Date.now().toString(),
      dateAdded: new Date().toISOString().split('T')[0],
    };
    setVehicles([...vehicles, newItem]);
  };

  const addPersonnel = (item: Omit<Personnel, 'id' | 'dateAdded'>) => {
    const newItem: Personnel = {
      ...item,
      id: Date.now().toString(),
      dateAdded: new Date().toISOString().split('T')[0],
    };
    setPersonnel([...personnel, newItem]);
  };

  const addACDV = (item: Omit<ACDV, 'id' | 'dateAdded'>) => {
    const newItem: ACDV = {
      ...item,
      id: Date.now().toString(),
      dateAdded: new Date().toISOString().split('T')[0],
    };
    setACDVData([...acdvData, newItem]);
  };

  // Update handlers for editing
  const updateEquipment = (updatedItem: Equipment) => {
    setEquipment(equipment.map(item => item.id === updatedItem.id ? updatedItem : item));
  };

  const updateVehicle = (updatedItem: Vehicle) => {
    setVehicles(vehicles.map(item => item.id === updatedItem.id ? updatedItem : item));
  };

  const updatePersonnel = (updatedItem: Personnel) => {
    setPersonnel(personnel.map(item => item.id === updatedItem.id ? updatedItem : item));
  };

  const updateACDV = (updatedItem: ACDV) => {
    setACDVData(acdvData.map(item => item.id === updatedItem.id ? updatedItem : item));
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard equipment={equipment} vehicles={vehicles} personnel={personnel} />;
      case 'equipment-form':
        return <EquipmentForm onSubmit={addEquipment} />;
      case 'vehicle-form':
        return <VehicleForm onSubmit={addVehicle} />;
      case 'personnel-form':
        return <PersonnelForm onSubmit={addPersonnel} />;
      case 'equipment-list':
        return <ResourceList type="equipment" data={equipment} onUpdate={updateEquipment} />;
      case 'vehicle-list':
        return <ResourceList type="vehicles" data={vehicles} onUpdate={updateVehicle} />;
      case 'personnel-list':
        return <ResourceList type="personnel" data={personnel} onUpdate={updatePersonnel} />;
      case 'gis-map':
        return <GISMap equipment={equipment} vehicles={vehicles} personnel={personnel} acdvData={acdvData} />;
      case 'agency-downloads':
        return <AgencyDownloads equipment={equipment} vehicles={vehicles} personnel={personnel} acdvData={acdvData} />;
      case 'acdv-form':
        return <ACDVForm onSubmit={addACDV} />;
      case 'acdv-list':
        return <ACDVList acdvData={acdvData} onUpdate={updateACDV} />;
      default:
        return <Dashboard equipment={equipment} vehicles={vehicles} personnel={personnel} />;
    }
  };

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen bg-gray-100">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} currentUser={currentUser} isAdmin={isAdmin} />
      <main className="flex-1 overflow-auto">
        <div className="p-6">
          {renderContent()}
        </div>
      </main>
    </div>
  );
}
